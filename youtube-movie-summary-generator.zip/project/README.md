<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/dd5e38b2-db2a-41a7-8cb1-ee4fe194aa03

## Run Locally

**Prerequisites:**  Node.js, **ffmpeg + ffprobe installed and available in your system PATH**


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## Rendu vidéo réel (ffmpeg)

L'export final de la vidéo (bouton "Compiler la Vidéo Summary") effectue un **vrai rendu côté serveur** via `ffmpeg` :
- Téléchargement des extraits Clip.Cafe assignés (ou de l'image de référence en mode Ken Burns si activée)
- Mixage de la narration (TTS) avec l'audio original du clip (volume réduit)
- Incrustation des sous-titres jaunes style cinéma
- Concatenation finale en MP4 (H.264 / AAC, 1920x1080)

**Important :** votre serveur de déploiement doit avoir `ffmpeg` et `ffprobe` installés (`apt install ffmpeg` sur Ubuntu/Debian, ou l'équivalent sur votre hébergeur). Sans ça, le rendu échouera avec un message d'erreur explicite.

Si votre reverse proxy (Nginx, Hostinger, etc.) a un timeout HTTP court, ce n'est pas un problème : le rendu se fait en tâche de fond (`POST /api/render/start` retourne immédiatement un `jobId`, puis le frontend interroge `GET /api/render/status/:jobId` toutes les 1.5s jusqu'à la fin).

Les fichiers rendus sont stockés dans `render-output/` (exclu de git) et nettoyés automatiquement après 24h.

