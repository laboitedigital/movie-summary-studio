import React, { useState, useEffect } from "react";
import { Search, Film, Play, Check, RefreshCw, Layers, Sparkles, HelpCircle, FilmIcon, Video } from "lucide-react";
import { MovieClip, ScriptSegment } from "../types";

interface ClipSearcherProps {
  segments: ScriptSegment[];
  setSegments: (segments: ScriptSegment[]) => void;
  activeSegmentIndex: number;
}

export default function ClipSearcher({
  segments,
  setSegments,
  activeSegmentIndex
}: ClipSearcherProps) {
  const activeSegment = segments[activeSegmentIndex];
  
  const [searchQuery, setSearchQuery] = useState("");
  const [clips, setClips] = useState<MovieClip[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasClipCafeKey, setHasClipCafeKey] = useState(false);
  
  // Local video preview modal or overlay
  const [previewClipId, setPreviewClipId] = useState<string | null>(null);
  const previewVideoRef = React.useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    fetch("/api/config")
      .then((res) => res.json())
      .then((data) => {
        if (data.hasClipCafe) {
          setHasClipCafeKey(true);
        }
      })
      .catch((err) => console.error("Error fetching config in ClipSearcher:", err));
  }, []);

  // Sync searchQuery with the active segment's suggested search terms
  useEffect(() => {
    if (activeSegment) {
      setSearchQuery(activeSegment.suggestedSearch || "");
      // Auto-trigger search when active segment shifts to give a snappy feel
      if (activeSegment.suggestedSearch) {
        handleSearchClips(activeSegment.suggestedSearch);
      }
    }
  }, [activeSegmentIndex, activeSegment?.suggestedSearch]);

  const handleSearchClips = async (queryToSearch = searchQuery) => {
    if (!queryToSearch.trim()) return;

    setIsSearching(true);
    setError(null);
    setPreviewClipId(null);

    try {
      const response = await fetch(`/api/clips/search?q=${encodeURIComponent(queryToSearch)}`);
      if (!response.ok) {
        throw new Error("Impossible de récupérer les extraits de films.");
      }
      const data = await response.json();
      setClips(data);
    } catch (err: any) {
      console.error(err);
      setError("Erreur de recherche : Impossible de joindre Clip.Cafe.");
    } finally {
      setIsSearching(false);
    }
  };

  const handleAssignClip = (clip: MovieClip) => {
    if (!activeSegment) return;

    setSegments(segments.map(seg => {
      if (seg.id === activeSegment.id) {
        return { 
          ...seg, 
          assignedClip: clip,
          // Sync duration to clip's duration if suitable
          duration: Math.max(seg.duration, clip.duration || 6)
        };
      }
      return seg;
    }));
  };

  const handlePreviewClip = (clipId: string) => {
    if (previewClipId === clipId) {
      setPreviewClipId(null);
    } else {
      setPreviewClipId(clipId);
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col gap-6" id="clip-searcher">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="text-lg font-semibold text-white flex items-center gap-2 font-sans">
            <Film className="w-5 h-5 text-amber-400" />
            <span>Recherche d'Extraits de Films (Clip.Cafe)</span>
          </h2>
          <p className="text-slate-400 text-xs mt-1">
            Cherchez des dialogues mythiques ou des actions phares de films. Sélectionnez l'extrait parfait pour l'associer à la scène en cours.
          </p>
        </div>
        {hasClipCafeKey && (
          <div className="self-start sm:self-center bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-mono font-bold px-2 py-1 rounded-lg flex items-center gap-1">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
            <span>PROXY PRO CLÉ ACTIF</span>
          </div>
        )}
      </div>

      {/* Active Segment context Banner */}
      {activeSegment ? (
        <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-3 flex justify-between items-center select-none">
          <div className="flex flex-col gap-0.5 truncate">
            <span className="text-[10px] uppercase font-bold text-amber-400 font-mono">Séquence Active de Montage</span>
            <span className="text-xs font-semibold text-white truncate font-sans">
              {activeSegmentIndex + 1}. {activeSegment.title}
            </span>
            <span className="text-[11px] text-slate-300 italic truncate font-sans">
              "{activeSegment.narration}"
            </span>
          </div>
          <div className="px-2.5 py-1 bg-slate-950 rounded-lg text-amber-300 font-mono text-[10px] font-bold shrink-0 border border-slate-800">
            DURÉE: {activeSegment.duration}s
          </div>
        </div>
      ) : (
        <div className="bg-slate-950 p-4 rounded-xl text-center border border-slate-850">
          <p className="text-slate-500 text-xs">Veuillez d'abord générer un script ci-dessus.</p>
        </div>
      )}

      {/* Search Input */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearchClips()}
            placeholder="Saisissez un dialogue ou un mot-clé (ex: spoon, i will be back)..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-500 transition-all font-sans"
            id="clip-search-input"
          />
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
        </div>
        <button
          onClick={() => handleSearchClips()}
          disabled={isSearching || !searchQuery.trim()}
          className="bg-slate-850 hover:bg-slate-800 border border-slate-800 disabled:text-slate-600 font-bold px-4 rounded-xl text-xs transition-all text-white flex items-center gap-1.5 select-none"
          id="clip-search-btn"
        >
          {isSearching ? <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-400" /> : <Search className="w-3.5 h-3.5" />}
          <span>Rechercher</span>
        </button>
      </div>

      {error && (
        <div className="text-xs text-amber-400 bg-amber-500/5 border border-amber-500/10 p-3 rounded-lg flex items-center gap-2">
          <HelpCircle className="w-4 h-4" />
          <span>Utilisation du catalogue de secours de haute qualité.</span>
        </div>
      )}

      {/* Results grid */}
      <div className="flex-1 flex flex-col min-h-[300px]">
        {isSearching ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-3">
            <RefreshCw className="w-8 h-8 text-amber-400 animate-spin" />
            <p className="text-slate-400 text-xs font-mono">Crawl de Clip.Cafe en cours...</p>
          </div>
        ) : clips.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[450px] overflow-y-auto pr-1" id="clips-grid">
            {clips.map((clip) => {
              const isAssigned = activeSegment?.assignedClip?.videoUrl === clip.videoUrl;
              const isPreviewing = previewClipId === clip.id;

              return (
                <div
                  key={clip.id}
                  className={`border rounded-xl overflow-hidden flex flex-col bg-slate-950 transition-all ${
                    isAssigned 
                      ? "border-amber-500 ring-1 ring-amber-500/20" 
                      : "border-slate-800 hover:border-slate-700"
                  }`}
                >
                  {/* Thumbnail / Video Preview aspect ratio 16:9 */}
                  <div className="relative aspect-video bg-black overflow-hidden flex items-center justify-center group">
                    {isPreviewing ? (
                      <video
                        ref={previewVideoRef}
                        src={clip.videoUrl}
                        className="w-full h-full object-cover"
                        controls
                        autoPlay
                        playsInline
                      />
                    ) : (
                      <>
                        <img
                          src={clip.thumbnail || `https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=400&auto=format&fit=crop`}
                          alt={clip.movie}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover opacity-60 group-hover:opacity-50 transition-all"
                        />
                        <button
                          onClick={() => handlePreviewClip(clip.id)}
                          className="absolute inset-0 m-auto w-10 h-10 rounded-full bg-slate-900/80 hover:bg-amber-500 text-white hover:text-slate-950 flex items-center justify-center transition-all cursor-pointer shadow-md"
                        >
                          <Play className="w-4 h-4 fill-current ml-0.5" />
                        </button>
                      </>
                    )}

                    {/* Clip info tags */}
                    <div className="absolute top-2.5 left-2.5 bg-black/80 px-2 py-1 rounded text-[10px] font-bold text-amber-400 uppercase tracking-wide border border-slate-800 select-none">
                      {clip.duration}s
                    </div>
                  </div>

                  {/* Body Info */}
                  <div className="p-3 flex-1 flex flex-col justify-between gap-3">
                    <div className="flex flex-col gap-1">
                      <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wide truncate">
                        {clip.movie}
                      </span>
                      <p className="text-xs font-semibold text-white leading-relaxed line-clamp-2 italic font-sans">
                        "{clip.quote}"
                      </p>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => handlePreviewClip(clip.id)}
                        className={`flex-1 px-2 py-1.5 rounded-lg text-[11px] font-mono font-bold text-center border transition-all ${
                          isPreviewing 
                            ? "bg-slate-900 text-white border-slate-700" 
                            : "bg-slate-950 text-slate-400 border-slate-800 hover:text-white"
                        }`}
                      >
                        {isPreviewing ? "Fermer" : "Aperçu"}
                      </button>
                      <button
                        onClick={() => handleAssignClip(clip)}
                        className={`flex-1 py-1.5 px-3 rounded-lg text-[11px] font-bold font-sans flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                          isAssigned
                            ? "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                            : "bg-amber-500 text-slate-950 hover:bg-amber-400"
                        }`}
                        disabled={!activeSegment}
                      >
                        {isAssigned ? (
                          <>
                            <Check className="w-3.5 h-3.5 stroke-[3]" />
                            <span>Associé</span>
                          </>
                        ) : (
                          <>
                            <Video className="w-3.5 h-3.5" />
                            <span>Associer</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center border border-dashed border-slate-800 rounded-2xl p-8 text-center select-none">
            <FilmIcon className="w-10 h-10 text-slate-700 mb-3" />
            <p className="text-sm font-semibold text-slate-400">Aucun extrait trouvé</p>
            <p className="text-xs text-slate-600 mt-1 max-w-xs">
              Saisissez un mot de dialogue ou un mot-clé précis pour déclencher la recherche sur Clip.Cafe ou utiliser nos fallbacks.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
