import { spawn } from "child_process";
import fs from "fs";
import path from "path";

export const RENDER_ROOT = path.join(process.cwd(), "render-output");

function ensureDir(p: string) {
  if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
}

function run(cmd: string, args: string[], timeoutMs = 120000): Promise<void> {
  return new Promise((resolve, reject) => {
    const proc = spawn(cmd, args);
    let stderr = "";
    const timer = setTimeout(() => {
      proc.kill("SIGKILL");
      reject(new Error(`${cmd} a dépassé le délai maximal (${timeoutMs}ms)`));
    }, timeoutMs);

    proc.stderr.on("data", (d) => {
      stderr += d.toString();
    });
    proc.on("error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
    proc.on("close", (code) => {
      clearTimeout(timer);
      if (code === 0) resolve();
      else reject(new Error(`${cmd} a échoué (code ${code}) :\n${stderr.slice(-1500)}`));
    });
  });
}

async function ffprobeDuration(filePath: string): Promise<number> {
  return new Promise((resolve) => {
    const proc = spawn("ffprobe", [
      "-v", "error",
      "-show_entries", "format=duration",
      "-of", "default=noprint_wrappers=1:nokey=1",
      filePath
    ]);
    let out = "";
    proc.stdout.on("data", (d) => (out += d.toString()));
    proc.on("close", () => {
      const val = parseFloat(out.trim());
      resolve(isNaN(val) ? 0 : val);
    });
    proc.on("error", () => resolve(0));
  });
}

async function downloadToFile(url: string, destPath: string): Promise<void> {
  const res = await fetch(url, { signal: AbortSignal.timeout(20000) });
  if (!res.ok) throw new Error(`Téléchargement échoué (HTTP ${res.status}) pour ${url}`);
  const buf = Buffer.from(await res.arrayBuffer());
  fs.writeFileSync(destPath, buf);
  if (fs.statSync(destPath).size < 1024) {
    throw new Error(`Fichier téléchargé trop petit / invalide : ${url}`);
  }
}

function decodeBase64DataUri(dataUri: string, destPath: string) {
  const match = dataUri.match(/^data:.*?;base64,(.*)$/);
  const base64 = match ? match[1] : dataUri;
  fs.writeFileSync(destPath, Buffer.from(base64, "base64"));
}

function wrapText(text: string, maxCharsPerLine = 42): string {
  const words = (text || "").split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let current = "";
  for (const w of words) {
    if ((current + " " + w).trim().length > maxCharsPerLine) {
      if (current) lines.push(current.trim());
      current = w;
    } else {
      current = (current + " " + w).trim();
    }
  }
  if (current) lines.push(current);
  return lines.join("\n");
}

const FONT_CANDIDATES = [
  "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
  "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
  "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
  "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
];

function findFont(): string | null {
  for (const candidate of FONT_CANDIDATES) {
    if (fs.existsSync(candidate)) return candidate;
  }
  return null;
}

const FONT_PATH = findFont();

export interface RenderSegmentInput {
  id: string;
  narration: string;
  duration: number;
  clipVideoUrl: string | null;
  imageUrl: string | null;
  useImage: boolean;
  ttsAudioDataUri: string | null;
}

export interface RenderResult {
  outputUrl: string;
  outputPath: string;
  durationSeconds: number;
}

type ProgressCallback = (pct: number, label: string) => void;

// Escape a path for use inside an ffmpeg filter option (colons and backslashes need escaping)
function escapeForFilter(p: string): string {
  return p.replace(/\\/g, "\\\\").replace(/:/g, "\\:");
}

export async function renderMovieSummary(
  jobId: string,
  movieTitle: string,
  segments: RenderSegmentInput[],
  onProgress?: ProgressCallback
): Promise<RenderResult> {
  ensureDir(RENDER_ROOT);
  const jobDir = path.join(RENDER_ROOT, jobId);
  ensureDir(jobDir);

  const totalSteps = segments.length + 1;
  let stepCount = 0;
  const report = (label: string) => {
    stepCount++;
    const pct = Math.min(95, Math.round((stepCount / totalSteps) * 90));
    onProgress?.(pct, label);
  };

  const segmentOutputs: string[] = [];

  for (let i = 0; i < segments.length; i++) {
    const seg = segments[i];
    const segDir = path.join(jobDir, `seg_${i}`);
    ensureDir(segDir);

    report(`Scène ${i + 1}/${segments.length} : ${(seg.narration || "").slice(0, 45)}...`);

    const outPath = path.join(segDir, "out.mp4");
    const audioExt = (seg.ttsAudioDataUri || "").startsWith("data:audio/mpeg") ? "mp3" : "wav";
    const audioInPath = path.join(segDir, `audio.${audioExt}`);
    const subPath = path.join(segDir, "subtitle.txt");

    // --- 1. Decode narration audio (if any) and determine real target duration ---
    let audioExists = false;
    let targetDuration = Math.max(2, seg.duration || 5);
    if (seg.ttsAudioDataUri) {
      try {
        decodeBase64DataUri(seg.ttsAudioDataUri, audioInPath);
        audioExists = true;
        const audioDur = await ffprobeDuration(audioInPath);
        if (audioDur > 0.3) {
          targetDuration = Math.max(2, audioDur + 0.4); // petit padding de respiration
        }
      } catch (e) {
        console.warn(`[render] Audio invalide pour la scène ${i}:`, e);
        audioExists = false;
      }
    }

    fs.writeFileSync(subPath, wrapText(seg.narration || ""));
    const drawtextFilter = FONT_PATH
      ? `,drawtext=fontfile='${escapeForFilter(FONT_PATH)}':textfile='${escapeForFilter(subPath)}':fontcolor=yellow:fontsize=42:borderw=3:bordercolor=black:x=(w-text_w)/2:y=h-th-70:line_spacing=8`
      : "";

    // --- 2. Try to build the segment: real clip -> reference image -> placeholder ---
    const attempts: Array<"clip" | "image" | "placeholder"> = [];
    if (seg.clipVideoUrl) attempts.push("clip");
    if (seg.useImage && seg.imageUrl) attempts.push("image");
    attempts.push("placeholder");

    let built = false;
    let lastErr: any = null;

    for (const mode of attempts) {
      try {
        if (mode === "clip") {
          const clipInPath = path.join(segDir, "clip_in.mp4");
          await downloadToFile(seg.clipVideoUrl as string, clipInPath);

          const videoFilters = `scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,setsar=1,fps=30${drawtextFilter}`;
          let filterComplex: string;
          const args = ["-y", "-stream_loop", "-1", "-i", clipInPath];

          if (audioExists) {
            args.push("-i", audioInPath);
            filterComplex = `[0:v]${videoFilters}[v];[0:a]volume=0.12[a0];[1:a]volume=1.0[a1];[a0][a1]amix=inputs=2:duration=longest:dropout_transition=0[aout]`;
          } else {
            filterComplex = `[0:v]${videoFilters}[v];[0:a]volume=1.0[aout]`;
          }

          args.push(
            "-filter_complex", filterComplex,
            "-map", "[v]", "-map", "[aout]",
            "-t", String(targetDuration),
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "21", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "192k", "-ar", "44100",
            outPath
          );
          await run("ffmpeg", args);
        } else if (mode === "image") {
          const imgInPath = path.join(segDir, "image_in.jpg");
          await downloadToFile(seg.imageUrl as string, imgInPath);

          const frames = Math.max(1, Math.round(targetDuration * 30));
          // Effet "Ken Burns" : léger zoom progressif sur l'image fixe
          const videoFilters = `scale=2200:-2,zoompan=z='min(zoom+0.0007,1.18)':d=${frames}:s=1920x1080:fps=30,setsar=1${drawtextFilter}`;
          const args = ["-y", "-loop", "1", "-i", imgInPath];
          let filterComplex: string;

          if (audioExists) {
            args.push("-i", audioInPath);
            filterComplex = `[0:v]${videoFilters}[v];[1:a]volume=1.0[aout]`;
          } else {
            filterComplex = `[0:v]${videoFilters}[v];anullsrc=channel_layout=stereo:sample_rate=44100[aout]`;
          }

          args.push(
            "-filter_complex", filterComplex,
            "-map", "[v]", "-map", "[aout]",
            "-t", String(targetDuration),
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "21", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "192k", "-ar", "44100",
            outPath
          );
          await run("ffmpeg", args);
        } else {
          // placeholder: fond cinématique sombre uni
          const videoFilters = `setsar=1${drawtextFilter}`;
          const args = [
            "-y",
            "-f", "lavfi", "-i", `color=c=0x11131a:s=1920x1080:r=30:d=${targetDuration + 0.5}`,
          ];
          let filterComplex: string;

          if (audioExists) {
            args.push("-i", audioInPath);
            filterComplex = `[0:v]${videoFilters}[v];[1:a]volume=1.0[aout]`;
          } else {
            filterComplex = `[0:v]${videoFilters}[v];anullsrc=channel_layout=stereo:sample_rate=44100[aout]`;
          }

          args.push(
            "-filter_complex", filterComplex,
            "-map", "[v]", "-map", "[aout]",
            "-t", String(targetDuration),
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "21", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "192k", "-ar", "44100",
            outPath
          );
          await run("ffmpeg", args);
        }

        built = true;
        break;
      } catch (e) {
        lastErr = e;
        console.warn(`[render] Scène ${i} - échec mode "${mode}":`, (e as Error).message);
      }
    }

    if (!built) {
      throw new Error(`Impossible de construire la scène ${i + 1} (${lastErr?.message || "erreur inconnue"})`);
    }

    segmentOutputs.push(outPath);
  }

  report("Assemblage final de la vidéo...");

  const concatListPath = path.join(jobDir, "concat.txt");
  const concatContent = segmentOutputs
    .map((p) => `file '${p.replace(/'/g, "'\\''")}'`)
    .join("\n");
  fs.writeFileSync(concatListPath, concatContent);

  const finalPath = path.join(jobDir, "final.mp4");
  await run("ffmpeg", ["-y", "-f", "concat", "-safe", "0", "-i", concatListPath, "-c", "copy", finalPath], 60000);

  const durationSeconds = await ffprobeDuration(finalPath);
  onProgress?.(100, "Rendu terminé avec succès !");

  return {
    outputUrl: `/render-output/${jobId}/final.mp4`,
    outputPath: finalPath,
    durationSeconds,
  };
}

// Nettoyage optionnel des anciens jobs (à appeler périodiquement, ex: cron ou au démarrage)
export function cleanupOldJobs(maxAgeMs = 24 * 60 * 60 * 1000) {
  if (!fs.existsSync(RENDER_ROOT)) return;
  const now = Date.now();
  for (const entry of fs.readdirSync(RENDER_ROOT)) {
    const fullPath = path.join(RENDER_ROOT, entry);
    try {
      const stat = fs.statSync(fullPath);
      if (now - stat.mtimeMs > maxAgeMs) {
        fs.rmSync(fullPath, { recursive: true, force: true });
      }
    } catch {
      // ignore
    }
  }
}
